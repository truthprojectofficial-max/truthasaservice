<#
.SYNOPSIS
Order Get It Right -- Build the Tauri desktop binary on Windows.
.DESCRIPTION
This script is intentionally small. It performs only the steps required
to produce a signed-ready Tauri MSI/NSIS bundle on a clean Windows host
that already has Node.js, Rust, and the WebView2 runtime installed.
#>

$ErrorActionPreference = "Stop"
$ProjectRoot = (Get-Location).Path
$TauriDir = Join-Path $ProjectRoot "02_Technical\tauri-shell"

Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "  Order Get It Right -- Tauri build harness" -ForegroundColor Cyan
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "  Project root:  $ProjectRoot"
Write-Host "  Tauri dir:     $TauriDir"
Write-Host "================================================================================" -ForegroundColor Cyan

# 1. Pre-flight: rust, node, webview2
foreach ($tool in @("rustc", "cargo", "node", "npm")) {
    $cmd = Get-Command $tool -ErrorAction SilentlyContinue
    if (-not $cmd) {
        throw "Required tool not found: $tool. Install Rust + Node.js before running."
    }
}

# 2. Build the Python runtime into the resources directory so the
#    Tauri bundle ships with a known-good interpreter.
$ResourceDir = Join-Path $TauriDir "resources"
New-Item -ItemType Directory -Force -Path $ResourceDir | Out-Null
$ProjectPython = "C:\Users\justo\OneDrive\Documents\to the spoils go\Python314"
if (Test-Path $ProjectPython) {
    Write-Host "[1/3] Bundling Python runtime from $ProjectPython" -ForegroundColor Yellow
    Copy-Item -Path $ProjectPython -Destination (Join-Path $ResourceDir "python") -Recurse -Force
} else {
    Write-Host "[1/3] No local Python found at $ProjectPython; bundle will assume the user has Python 3.12+ on PATH" -ForegroundColor DarkYellow
}

# 3. Install npm deps
Write-Host "[2/3] Installing Tauri npm dependencies" -ForegroundColor Yellow
Set-Location $TauriDir
if (-not (Test-Path "node_modules")) {
    npm install
}

# 4. Build
Write-Host "[3/3] Running tauri build" -ForegroundColor Yellow
npx tauri build
Set-Location $ProjectRoot
Write-Host "Tauri build complete. Artifacts under $TauriDir\target\release\bundle" -ForegroundColor Green
