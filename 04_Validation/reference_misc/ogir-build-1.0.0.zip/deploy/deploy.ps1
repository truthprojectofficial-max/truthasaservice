<#
.SYNOPSIS
Order Get It Right -- Idempotent Windows installer / launcher.
#>

$ErrorActionPreference = "Stop"
$ProjectRoot = (Get-Location).Path
$ProjectName = "Order Get It Right"
$ProjectVersion = "1.0.0"
$ProjectOperator = "Justin Barnett"
$InstallPath = "C:\OrderGetItRight"
$LocalPython = Join-Path $ProjectRoot "02_Technical\python"
$LauncherDir = Join-Path $InstallPath "launchers"
New-Item -ItemType Directory -Force -Path $LauncherDir | Out-Null

function Write-Deploy-Log {
    param([string]$Message)
    $logFile = Join-Path $InstallPath "04_Validation\deploy.log"
    $entry = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Message"
    Add-Content -Path $logFile -Value $entry -ErrorAction SilentlyContinue
    Write-Host "  -> $entry" -ForegroundColor Green
}

Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "          $ProjectName  --  WINDOWS DEPLOYMENT                              " -ForegroundColor Cyan
Write-Host "          Version $ProjectVersion                                            " -ForegroundColor Cyan
Write-Host "          Operator: $ProjectOperator                                          " -ForegroundColor Cyan
Write-Host "================================================================================" -ForegroundColor Cyan

# 1. Mirror the project tree to the install path
foreach ($folder in @("00_Strategy", "01_Methodology", "02_Technical", "03_Vault", "04_Validation", "99_Archive", "data", "docs", "tests", "deploy")) {
    $src = Join-Path $ProjectRoot $folder
    $dst = Join-Path $InstallPath $folder
    if (Test-Path $src) {
        New-Item -ItemType Directory -Force -Path $dst | Out-Null
        Copy-Item -Path (Join-Path $src "*") -Destination $dst -Recurse -Force
        Write-Deploy-Log "Mirrored $folder to $dst"
    }
}

# 2. Python runtime
$PythonExe = $null
if (Test-Path $LocalPython) {
    $PythonExe = Join-Path $LocalPython "python.exe"
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $PythonExe = (Get-Command python).Source
}
if (-not $PythonExe) {
    throw "No Python interpreter found. Install Python 3.12+ before running this script."
}
Write-Deploy-Log "Python runtime: $PythonExe"

# 3. Install dependencies
Write-Deploy-Log "Installing Python dependencies"
& $PythonExe -m pip install --upgrade pip --no-warn-script-location
$ReqFile = Join-Path $InstallPath "02_Technical\requirements.txt"
if (Test-Path $ReqFile) {
    & $PythonExe -m pip install -r $ReqFile --no-warn-script-location
}

# 4. Generate convenience launchers
$StartBat = @"
@echo off
setlocal
cd /d $InstallPath\02_Technical
"$PythonExe" -m uvicorn src.server:app --host 127.0.0.1 --port 3000
"@
Set-Content -LiteralPath (Join-Path $LauncherDir "Start-Server.bat") -Value $StartBat -Encoding ASCII

$CliBat = @"
@echo off
setlocal
cd /d $InstallPath\02_Technical
"$PythonExe" -m src.audit_cli %*
"@
Set-Content -LiteralPath (Join-Path $LauncherDir "Run-AuditCli.bat") -Value $CliBat -Encoding ASCII

$VerifyBat = @"
@echo off
setlocal
cd /d $InstallPath
"$PythonExe" -m pytest tests/ -v
"@
Set-Content -LiteralPath (Join-Path $LauncherDir "Verify-Tests.bat") -Value $VerifyBat -Encoding ASCII

$BuildTauriBat = @"
@echo off
setlocal
cd /d $InstallPath
powershell -ExecutionPolicy Bypass -File deploy\build-tauri.ps1
"@
Set-Content -LiteralPath (Join-Path $LauncherDir "Build-Tauri-Desktop.bat") -Value $BuildTauriBat -Encoding ASCII

# 5. Build Tauri desktop binary if requested
if ($env:OGIR_BUILD_TAURI -eq "1") {
    Write-Host "Building Tauri desktop binary (OGIR_BUILD_TAURI=1)" -ForegroundColor Cyan
    & $PSScriptRoot\build-tauri.ps1
}

Write-Host ""
Write-Host "================================================================================" -ForegroundColor Green
Write-Host "    DEPLOYMENT COMPLETE" -ForegroundColor Green
Write-Host "================================================================================" -ForegroundColor Green
Write-Host "Install path:         $InstallPath"
Write-Host "Start server:         $LauncherDir\Start-Server.bat"
Write-Host "Run CLI audit:        $LauncherDir\Run-AuditCli.bat"
Write-Host "Run tests:            $LauncherDir\Verify-Tests.bat"
Write-Host "Build Tauri binary:   $LauncherDir\Build-Tauri-Desktop.bat"
Write-Host ""
Write-Host "When the Tauri binary is built, you can also run Order Get It Right as a" -ForegroundColor Cyan
Write-Host "single double-clickable desktop application with no Python install required." -ForegroundColor Cyan
Write-Host "================================================================================" -ForegroundColor Green
