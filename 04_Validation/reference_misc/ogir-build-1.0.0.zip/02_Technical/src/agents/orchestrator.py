"""
Order Get It Right -- Agent Orchestrator

The single runtime entry point that drives the agent chain.  Agents do
not call each other directly.  All hand-offs go through the job
delegator.  The orchestrator is the operator-facing surface.

Agent set (deterministic, no LLM):
  - Form_Entry_Agent       (01)
  - Audit_Review_Agent     (02)  -- 52-pattern deception scan
  - Lattice_Compute_Agent  (01)  -- Real-Options binomial lattice
  - Ledger_Seal_Agent      (03)  -- Merkle seal to the vault
  - Affidavit_Agent        (04)  -- Section 177 certificate

URN format: OGIR:<SPACE>:<ACTION>
"""
import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from config.constants import (
    PROJECT_NAME,
    PROJECT_VERSION,
    PROJECT_OPERATOR,
    PROJECT_VAULT_DIR,
)
from src.types import ProductEvidence, DeceptionReport
from src.engines import deception_scanner, bbfb_engine, real_options_lattice
from src.engines import facts_registry
from src.io import vault_io
from src.agents import tau_firewall, job_delegator


class Orchestrator:
    """The single runtime entry point.  Owns the delegator and the firewall."""

    def __init__(self) -> None:
        self.system_id = f"{PROJECT_NAME} v{PROJECT_VERSION}"
        self.operator = PROJECT_OPERATOR
        self.tau = tau_firewall.TauFirewall()
        self.delegator = job_delegator.AgentJobDelegator(
            tau=self.tau,
            registry_path=None,
        )
        # Seed the in-memory facts registry with grounding facts
        facts_registry.reset_registry()
        facts_registry.add_fact(
            "Governance",
            f"{PROJECT_NAME} enforces the agent chain via the job delegator.",
            "system",
        )
        facts_registry.add_fact(
            "Forensic",
            "All deception detections use the deterministic 52-pattern ontology v3.8.",
            "system",
        )
        facts_registry.add_fact(
            "Technical",
            "BBFB engine uses LAW/GRACE/FRUIT decomposition with quadratic penalty.",
            "system",
        )

    # ------------------------------------------------------------------
    def process_input(
        self,
        category: str,
        statement: str,
        product_evidence: Optional[ProductEvidence] = None,
    ) -> Dict[str, Any]:
        """Run the full agent chain on a single input.
        
        Hand-off sequence (every step is a sealed job token):
          Form_Entry_Agent -> Audit_Review_Agent -> Lattice_Compute_Agent -> Ledger_Seal_Agent
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        if category not in {"Technical", "Governance", "Forensic"}:
            return {
                "timestamp": timestamp,
                "finalAction": "REFUSED",
                "reason": f"Invalid category {category!r}",
            }

        # Step 1: Form_Entry_Agent -- draft the fact
        draft_token = self.delegator.create_job_token(
            assigner="Form_Entry_Agent",
            target_agent="Form_Entry_Agent",
            task_urn="OGIR:02:FORM_ENTRY",
            data={"category": category, "statement": statement[:500]},
        )
        self.delegator.claim_job(draft_token)
        fact = facts_registry.add_fact(category, statement[:500], "Form_Entry_Agent")
        self.delegator.close_job(draft_token, result_hash=str(fact["id"]), status="COMPLETED")

        # Step 2: Audit_Review_Agent -- run the 52-pattern scan
        audit_token = self.delegator.create_job_token(
            assigner="Form_Entry_Agent",
            target_agent="Audit_Review_Agent",
            task_urn="OGIR:02:AUDIT_TEXT",
            data={"statement": statement},
        )
        self.delegator.claim_job(audit_token)
        deception_result = deception_scanner.audit_text(statement)
        verdict = self._classify_deception(deception_result)
        if verdict == "SUPPRESSED":
            # CRITICAL pattern: refuse the entire cycle
            self.delegator.close_job(
                audit_token,
                result_hash="STRUCTURAL_REFUSAL",
                status="REFUSED",
            )
            refusal_token = self.delegator.create_job_token(
                assigner="Audit_Review_Agent",
                target_agent="Ledger_Seal_Agent",
                task_urn="OGIR:03:SEAL_REFUSAL",
                data={"fact_id": fact["id"], "reason": "CRITICAL deception pattern detected"},
            )
            self.delegator.claim_job(refusal_token)
            vault_io.append_block(
                "REFUSAL",
                {"fact_id": fact["id"], "verdict": "SUPPRESSED", "patterns": [p.patternId for p in deception_result.detectedPatterns]},
            )
            self.delegator.close_job(refusal_token, result_hash="SEALED", status="COMPLETED")
            return {
                "timestamp": timestamp,
                "finalAction": "REFUSED",
                "reason": "CRITICAL deception pattern detected -- structural refusal",
                "deceptionScore": deception_result.deceptionProbability,
                "patternsFired": [p.patternId for p in deception_result.detectedPatterns],
                "ledgerRoot": vault_io.merkle_stats()["merkleRoot"],
            }
        self.delegator.close_job(audit_token, result_hash=verdict, status="COMPLETED")

        # Step 3: Lattice_Compute_Agent -- if evidence was supplied
        valuation_token = None
        valuation_dict = None
        if product_evidence is not None:
            valuation_token = self.delegator.create_job_token(
                assigner="Audit_Review_Agent",
                target_agent="Lattice_Compute_Agent",
                task_urn="OGIR:01:COMPUTE_LATTICE",
                data={"productName": product_evidence.productName},
            )
            self.delegator.claim_job(valuation_token)
            valuation = real_options_lattice.hardened_compound_binomial_gate(
                deception_score=deception_result.deceptionProbability,
                entropy=deception_result.entropy.shannonEntropy,
            )
            valuation_dict = valuation.model_dump()
            self.delegator.close_job(valuation_token, result_hash=valuation_dict["totalValue"], status="COMPLETED")

        # Step 4: BBFB engine (sibling of lattice, same gate)
        bbfb_dict = None
        if product_evidence is not None:
            bbfb_result = bbfb_engine.calculate_bbfb(product_evidence)
            bbfb_dict = bbfb_result.model_dump()

        # Step 5: Ledger_Seal_Agent -- seal to the Merkle chain
        seal_token = self.delegator.create_job_token(
            assigner="Lattice_Compute_Agent" if valuation_token else "Audit_Review_Agent",
            target_agent="Ledger_Seal_Agent",
            task_urn="OGIR:03:SEAL_FACT",
            data={"fact_id": fact["id"]},
        )
        self.delegator.claim_job(seal_token)
        seal_block = vault_io.append_block(
            "AUDIT_CYCLE_COMPLETE",
            {
                "fact_id": fact["id"],
                "deceptionScore": deception_result.deceptionProbability,
                "isDeceptive": deception_result.structuralDeceptionFlag,
                "verdict": verdict,
                "bbfbCompliant": bbfb_dict["overallCompliant"] if bbfb_dict else None,
                "valuationDecision": valuation_dict["decision"] if valuation_dict else None,
            },
        )
        self.delegator.close_job(seal_token, result_hash=seal_block["current_hash"], status="COMPLETED")

        # Step 6: Decide
        if verdict == "FLAGGED":
            final_action = "REVIEW_REQUIRED"
            reason = "HIGH deception pattern flagged -- review required before proceeding"
        elif bbfb_dict and not bbfb_dict["overallCompliant"]:
            final_action = "REJECT"
            reason = "BBFB non-compliant -- economic harm substantiated"
        elif valuation_dict and valuation_dict["decision"] == "DEFER":
            final_action = "TEST FIRST"
            reason = f"Compound option value below threshold ({valuation_dict['totalValue']})"
        else:
            final_action = "GO"
            reason = "Within limits -- proceed"

        return {
            "timestamp": timestamp,
            "factId": fact["id"],
            "systemId": self.system_id,
            "operator": self.operator,
            "deceptionGate": {
                "score": round(deception_result.deceptionProbability, 4),
                "isDeceptive": deception_result.structuralDeceptionFlag,
                "verdict": verdict,
                "entropy": deception_result.entropy.shannonEntropy,
                "patternsMatched": len(deception_result.detectedPatterns),
            },
            "valuationGate": (
                {
                    "decision": valuation_dict["decision"],
                    "totalValue": valuation_dict["totalValue"],
                    "threshold": valuation_dict["threshold"],
                }
                if valuation_dict
                else None
            ),
            "bbfbGate": bbfb_dict,
            "finalAction": final_action,
            "reason": reason,
            "ledgerRoot": seal_block["current_hash"],
            "tau": self.tau.stats(),
        }

    # ------------------------------------------------------------------
    @staticmethod
    def _classify_deception(report: DeceptionReport) -> str:
        """Three-state verdict: CLEAN / FLAGGED / SUPPRESSED.
        
        SUPPRESSED fires on any CRITICAL pattern, regardless of probability.
        FLAGGED fires on any HIGH pattern.
        CLEAN otherwise.
        """
        if any(p.severity == "CRITICAL" for p in report.detectedPatterns):
            return "SUPPRESSED"
        if any(p.severity == "HIGH" for p in report.detectedPatterns):
            return "FLAGGED"
        return "CLEAN"

    # ------------------------------------------------------------------
    def shutdown(self) -> None:
        """Seal the final state of the delegator."""
        self.delegator.ledger.append("SHUTDOWN", {"operator": self.operator})


# Backwards-compatible alias for the previous test suite
GroknettCore = Orchestrator


if __name__ == "__main__":
    core = Orchestrator()
    sample_evidence = ProductEvidence(
        productName="Audio Pro W-Generation",
        pricePaid=599,
        priceAdvertised=599,
        specClaimed=106,
        specClaimedUnit="dB",
        specMeasured=94,
        warrantyMonths=24,
        monthsToFailure=18,
        knownIssues=3,
        totalFeaturesOrParts=12,
        regulatoryRequirements=4,
        violationsFound=1,
        notes="Sample evidence for live demo.",
    )
    result = core.process_input(
        category="Governance",
        statement=(
            "I apologize for the confusion. Based on my analysis the data clearly shows this is "
            "100% accurate and has never failed. We will provide a full replacement as a courtesy."
        ),
        product_evidence=sample_evidence,
    )
    print(json.dumps(result, indent=2, default=str))
    core.shutdown()