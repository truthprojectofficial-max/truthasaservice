"""
Order Get It Right -- HTTP API smoke tests.

These tests are the only tests in the project.  They go through the
FastAPI HTTP API only.  No file under tests/ imports from src/.

The boundary test in test_00_99_boundary.py enforces this rule on
every file in tests/.
"""
import os
import sys
import shutil
import tempfile
from pathlib import Path

# Make the 02_Technical directory importable so we can import the
# FastAPI app and the TestClient.  The app object is what the boundary
# test protects: it is the public surface, not the source tree.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
TECHNICAL = PROJECT_ROOT / "02_Technical"
sys.path.insert(0, str(TECHNICAL))

# The app object itself is part of the API surface and is allowed to
# be imported into tests for the purpose of mounting TestClient.
# This is the ONLY src import the tests make.  The boundary test
# in test_00_99_boundary.py explicitly whitelists this pattern.
from src.server.app import app  # noqa: E402

from fastapi.testclient import TestClient  # noqa: E402

client = TestClient(app)


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "operational"
    assert body["project"] == "Order Get It Right"
    assert body["version"] == "1.0.0"


def test_system_status():
    r = client.get("/api/status")
    assert r.status_code == 200
    body = r.json()
    assert body["operator"] == "Justin Barnett"
    assert "52 patterns" in body["ontologyVersion"]


def test_analyze_deceptive():
    text = (
        "I apologize for the confusion. Based on my analysis the data clearly "
        "shows this is 100% accurate and never failed."
    )
    r = client.post("/api/analyze", json={"text": text})
    assert r.status_code == 200
    data = r.json()
    assert data["deceptionProbability"] > 0
    assert len(data["detectedPatterns"]) > 0


def test_analyze_clean():
    text = (
        "The device model is C10 MKII. Measured output is 94 dB. "
        "Rated output is 106 dB. Gap: 12 dB."
    )
    r = client.post("/api/analyze", json={"text": text})
    assert r.status_code == 200
    data = r.json()
    assert data["deceptionProbability"] < 0.5


def test_bbfb_compliant():
    r = client.post(
        "/api/calculate",
        json={
            "evidence": {
                "productName": "C10 MKII",
                "pricePaid": 599,
                "priceAdvertised": 599,
                "specClaimed": 106,
                "specClaimedUnit": "dB",
                "specMeasured": 100,
                "warrantyMonths": 24,
                "monthsToFailure": 18,
                "knownIssues": 0,
                "totalFeaturesOrParts": 12,
                "regulatoryRequirements": 4,
                "violationsFound": 0,
                "notes": "",
            }
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["overallCompliant"] is True
    assert body["fruit"]["compositeValueScore"] > 0


def test_bbfb_noncompliant():
    r = client.post(
        "/api/calculate",
        json={
            "evidence": {
                "productName": "Bad Speaker",
                "pricePaid": 599,
                "priceAdvertised": 599,
                "specClaimed": 106,
                "specClaimedUnit": "dB",
                "specMeasured": 40,
                "warrantyMonths": 6,
                "monthsToFailure": 3,
                "knownIssues": 10,
                "totalFeaturesOrParts": 12,
                "regulatoryRequirements": 4,
                "violationsFound": 4,
                "notes": "",
            }
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["overallCompliant"] is False


def test_evaluation_suite():
    r = client.get("/api/eval/run")
    assert r.status_code == 200
    body = r.json()
    assert body["metrics"]["totalCases"] == 8
    assert body["metrics"]["accuracy"] >= 0.0
    assert body["metrics"]["f1Score"] >= 0.0


def test_acl_demand():
    r = client.post(
        "/api/acl-demand",
        json={
            "invoice_spec": "Gen 2",
            "hardware_id": "W-Gen",
            "text": "I apologize for the confusion.",
            "consumer_name": "Justin",
            "supplier_name": "AudioPro",
        },
    )
    assert r.status_code == 200
    assert "Australian Consumer Law Section 56" in r.json()["demand"]


def test_facts_listing():
    r = client.get("/api/facts")
    assert r.status_code == 200
    facts = r.json()["facts"]
    assert isinstance(facts, list)


def test_ledger_present():
    r = client.get("/api/ledger")
    assert r.status_code == 200
    body = r.json()
    assert "stats" in body
    assert "blocks" in body


def test_ontology_has_52_patterns():
    """The 52-pattern ontology is exposed via the HTTP API, not by import."""
    r = client.get("/api/ontology")
    assert r.status_code == 200
    body = r.json()
    assert body["count"] == 52
    assert body["version"] == "3.8 (52 patterns)"
    ids = [p["id"] for p in body["patterns"]]
    expected = [f"DD-{i:03d}" for i in range(1, 53)]
    assert ids == expected


def test_all_patterns_have_indicators():
    r = client.get("/api/ontology")
    body = r.json()
    for p in body["patterns"]:
        assert len(p["indicators"]) > 0, f"{p['id']} has no indicators"
        assert p["severity"] in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}


def test_evidence_parser_via_http():
    """The evidence parser is exposed via HTTP, not by import."""
    text = (
        "The Audio Pro Gen 2 was advertised at $599. We paid $599. "
        "Measured gain is 94 dB, rated 106 dB. Warranty 24 months. "
        "It failed after 18 months. 3 issues out of 12 features. "
        "1 violation of 4 requirements."
    )
    r = client.post("/api/parse/evidence", json={"text": text})
    assert r.status_code == 200
    body = r.json()
    assert body["parsed"] is not None
    assert body["parsed"]["price_paid"] == 599.0
    assert body["parsed"]["price_advertised"] == 599.0
    assert body["parsed"]["spec_measured"] == 94.0
    assert body["parsed"]["spec_claimed"] == 106.0
    assert body["parsed"]["warranty_months"] == 24.0
    assert body["parsed"]["months_to_failure"] == 18.0


def test_changelog_append_and_list():
    r = client.post(
        "/api/changelog",
        json={
            "type": "incident",
            "summary": "Test incident from pytest",
            "details": "Synthetic incident to verify the changelog is wired.",
            "binId": "test-runner",
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["type"] == "incident"
    assert body["summary"].startswith("Test incident")
    assert "timestamp" in body
    r2 = client.get("/api/changelog")
    assert r2.status_code == 200
    entries = r2.json()["entries"]
    assert any(e["type"] == "incident" for e in entries)


def test_mcp_create_job():
    r = client.post(
        "/api/mcp/jobs",
        json={
            "assigner": "Form_Entry_Agent",
            "target_agent": "Audit_Review_Agent",
            "task_urn": "OGIR:02:AUDIT_TEXT",
            "data": {"statement": "test"},
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert "jobId" in body
    assert len(body["jobId"]) == 64  # SHA-256 hex


def test_mcp_urn_validation():
    r = client.post(
        "/api/mcp/jobs",
        json={
            "assigner": "A",
            "target_agent": "B",
            "task_urn": "BAD:02:ACTION",
            "data": {},
        },
    )
    assert r.status_code == 400


def test_mcp_list_jobs():
    r = client.get("/api/mcp/jobs")
    assert r.status_code == 200
    assert "jobs" in r.json()


def test_mcp_tau_stats():
    r = client.get("/api/mcp/tau")
    assert r.status_code == 200
    body = r.json()
    assert body["ceiling"] == 0.10
    assert "auditMsTotal" in body
    assert "extractionRatio" in body


def test_mcp_stats():
    r = client.get("/api/mcp/stats")
    assert r.status_code == 200
    body = r.json()
    assert "jobCount" in body
    assert "byStatus" in body
    assert "tau" in body


def test_mcp_full_cycle():
    """Run a full MCP cycle: create, claim, close."""
    r = client.post(
        "/api/mcp/jobs",
        json={
            "assigner": "A",
            "target_agent": "B",
            "task_urn": "OGIR:01:TEST",
            "data": {},
        },
    )
    job_id = r.json()["jobId"]
    r = client.post(f"/api/mcp/jobs/{job_id}/claim")
    assert r.status_code == 200
    assert r.json()["status"] == "IN_PROGRESS"
    r = client.post(
        f"/api/mcp/jobs/{job_id}/close",
        json={"result_hash": "abc123", "status": "COMPLETED"},
    )
    assert r.status_code == 200
    assert r.json()["status"] == "COMPLETED"
    assert r.json()["result_seal"] == "abc123"


def test_orchestrator_end_to_end_deceptive():
    """The full orchestrator path through the HTTP API."""
    r = client.post(
        "/api/orchestrator/process",
        json={
            "category": "Governance",
            "statement": "I apologize. Based on my analysis the data clearly shows this is 100% accurate.",
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["finalAction"] == "REFUSED"
    assert "patternsFired" in body
    assert len(body["patternsFired"]) > 0


def test_orchestrator_end_to_end_clean():
    r = client.post(
        "/api/orchestrator/process",
        json={
            "category": "Technical",
            "statement": "The product model is C10 MKII. Measured output 94 dB. Rated 106 dB. Gap 12 dB.",
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["deceptionGate"]["verdict"] == "CLEAN"
    assert body["finalAction"] in {"GO", "REVIEW_REQUIRED"}


def test_orchestrator_with_evidence():
    r = client.post(
        "/api/orchestrator/process",
        json={
            "category": "Governance",
            "statement": "Standard compliance report with normal language.",
            "product_evidence": {
                "productName": "Test",
                "pricePaid": 599,
                "priceAdvertised": 599,
                "specClaimed": 106,
                "specClaimedUnit": "dB",
                "specMeasured": 100,
                "warrantyMonths": 24,
                "monthsToFailure": 18,
            },
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert "valuationGate" in body
    assert "bbfbGate" in body